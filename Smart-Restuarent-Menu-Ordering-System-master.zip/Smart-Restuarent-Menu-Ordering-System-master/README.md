# ReMen : ReMen: Web-based application for menu organizing system
The food ordering system is proposed with the use of a handheld device placed on each table which is used to make an order at the restaurant.
It's accoplished with only c++.
